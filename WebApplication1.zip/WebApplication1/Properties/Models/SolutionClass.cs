using System;

namespace TSPApi.Models
{
    public static class SolutionClass
    {
        public static double TSP(int mask, int pos, int N, int[,] dp, double[,] dist)
        {
            const int INF = int.MaxValue;
            if (mask == (1 << N) - 1)
            {
                return dist[pos, 0];
            }
            if (dp[mask, pos] != -1)
            {
                return dp[mask, pos];
            }
            double ans = INF;
            for (int city = 0; city < N; city++)
            {
                if ((mask & (1 << city)) == 0)
                {
                    double newAns = dist[pos, city] + TSP(mask | (1 << city), city, N, dp, dist);
                    ans = Math.Min(ans, Math.Round(newAns));
                }
            }
            return dp[mask, pos] = Convert.ToInt32(ans);
        }
    }
}
